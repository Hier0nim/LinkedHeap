#!/usr/bin/env python3
import http.server, socketserver, webbrowser, os

PORT = 5001
ROOT = os.path.join(os.path.dirname(__file__), "wwwroot")

os.chdir(ROOT)
handler = http.server.SimpleHTTPRequestHandler

with socketserver.TCPServer(("", PORT), handler) as httpd:
    webbrowser.open(f"http://localhost:{PORT}")
    print(f"Serving wwwroot at http://localhost:{PORT}")
    httpd.serve_forever()
