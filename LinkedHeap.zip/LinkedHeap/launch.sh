#!/usr/bin/env bash
# make executable: chmod +x launch.sh

# find python
if command -v python3 &>/dev/null; then PY=python3
elif command -v python &>/dev/null; then PY=python
else
  echo "Python not found; install Python 3." >&2
  exit 1
fi

"$PY" "$(dirname "$0")/serve.py"
