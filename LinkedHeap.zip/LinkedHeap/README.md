## Zawartość
- **wwwroot/** – pliki statyczne Blazor WASM  
- **serve.py** – uruchamia lokalny serwer HTTP na porcie 5000 i otwiera przeglądarkę  
- **launch.bat** – Windows  
- **launch.sh** – macOS/Linux  

## Użytkowanie
1. Rozpakuj folder.  
2. **Windows:** dwuklik w `launch.bat`.  
3. **macOS/Linux:**  
   - `chmod +x launch.sh`  
   - dwuklik lub `./launch.sh`.  
4. Aplikacja otworzy się pod **http://localhost:5000**.  

## Rozwiązywanie problemów
- **Python nie znaleziony:** zainstaluj Python 3 i dodaj do PATH.  
- **Port zajęty:** zmodyfikuj wartość `PORT` w `serve.py`.  
